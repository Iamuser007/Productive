package com.example.trff

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
