import 'package:flutter/material.dart';

class PowerUpManager {
  // Helper methods for power-up management

  Widget buildPowerUpButton({
    required String emojiIcon,
    required int count,
    required String label,
    required VoidCallback onTap,
    required bool isActive,
  }) {
    return Opacity(
      opacity: isActive ? 1.0 : 0.5,
      child: GestureDetector(
        onTap: isActive ? onTap : null,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 6, horizontal: 10),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.8),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isActive ? Colors.blue : Colors.grey,
              width: 2,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(emojiIcon, style: TextStyle(fontSize: 20)),
              SizedBox(width: 4),
              Text('x$count', style: TextStyle(fontSize: 14)),
              SizedBox(width: 4),
              Text(label, style: TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  // Additional helper methods for powerup management could be added here
  // For example, methods to check if a power-up can be used
  bool canUseTortoise(int count) => count > 0;
  bool canUseLemonHeart(int count, int currentLives, int maxLives) =>
      count > 0 && currentLives < maxLives;
}
