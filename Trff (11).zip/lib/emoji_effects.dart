import 'dart:math';
import 'package:flutter/material.dart';

class Particle {
  Offset position;
  Offset velocity;
  double size;
  String emoji;
  double opacity;
  double rotation;
  double rotationSpeed;

  Particle({
    required this.position,
    required this.velocity,
    required this.size,
    required this.emoji,
    this.opacity = 1.0,
    this.rotation = 0.0,
    this.rotationSpeed = 0.0,
  });

  void update() {
    position = position + velocity;
    opacity -= 0.03;
    size -= 0.5;
    rotation += rotationSpeed;
  }

  bool isVisible() {
    return opacity > 0 && size > 0;
  }
}

class EmojiEffects {
  final TickerProviderStateMixin vsync;
  List<Particle> particles = [];
  late AnimationController _particleController;
  final Random random = Random();

  EmojiEffects(this.vsync) {
    _particleController = AnimationController(
      vsync: vsync,
      duration: Duration(milliseconds: 500),
    )..addListener(_updateParticles);
  }

  void _updateParticles() {
    for (int i = particles.length - 1; i >= 0; i--) {
      particles[i].update();
      if (!particles[i].isVisible()) {
        particles.removeAt(i);
      }
    }
    if (particles.isEmpty) {
      _particleController.stop();
    }
  }

  void createScatterEffect(Offset position, String emoji) {
    particles.clear();

    for (int i = 0; i < 15; i++) {
      double angle = random.nextDouble() * 2 * pi;
      double speed = 2.0 + random.nextDouble() * 3.0;

      particles.add(
        Particle(
          position: position,
          velocity: Offset(cos(angle) * speed, sin(angle) * speed),
          size: 20.0 + random.nextDouble() * 10,
          emoji: emoji,
          rotation: random.nextDouble() * 2 * pi,
          rotationSpeed: (random.nextDouble() - 0.5) * 0.2,
        ),
      );
    }

    if (!_particleController.isAnimating) {
      _particleController.repeat();
    }
  }

  List<Widget> buildParticles() {
    return particles.map((particle) {
      return Positioned(
        left: particle.position.dx,
        top: particle.position.dy,
        child: Transform.rotate(
          angle: particle.rotation,
          child: Opacity(
            opacity: particle.opacity,
            child: Text(
              particle.emoji,
              style: TextStyle(fontSize: particle.size),
            ),
          ),
        ),
      );
    }).toList();
  }

  void dispose() {
    _particleController.dispose();
  }
}
