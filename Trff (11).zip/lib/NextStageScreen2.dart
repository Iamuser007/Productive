import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'game_screen.dart';
import 'MainScreen.dart';
import 'LeaderboardScreen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const SpaceInvadersApp());
}

class SpaceInvadersApp extends StatelessWidget {
  const SpaceInvadersApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Space Invaders',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/game', // Start app at GameScreenSpace
      onGenerateRoute: (settings) {
        // Handle dynamic route with arguments
        if (settings.name == '/game') {
          final args = settings.arguments as Map?;
          return MaterialPageRoute(
            builder: (context) => GameScreenSpace(
              playerName: args?['playerName'] ?? 'Player1',
            ),
          );
        }

        // You can handle other dynamic routes here if needed

        // Default fallback route
        return MaterialPageRoute(
          builder: (context) => MainScreen(),
        );
      },
      routes: {
        '/main': (context) => MainScreen(),
        '/leaderboard': (context) => LeaderboardScreen(),
        // Optional static route for game (if you navigate without arguments)
        // but not used if you're using onGenerateRoute for '/game'
      },
    );
  }
}
