import 'dart:ui';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';
import 'GameScreen.dart';
import 'game_screen.dart';
import 'LeaderboardScreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Target Blast',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: GoogleFonts.pressStart2pTextTheme(),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with TickerProviderStateMixin {
  TextEditingController nameController = TextEditingController();
  bool isStage2Unlocked = false;
  String playerName = '';
  late AnimationController _backgroundController;
  late AnimationController _glowController;
  late AnimationController _bannerGlowController;
  late AnimationController _footerFadeController;
  late AnimationController _footerPulseController;

  @override
  void initState() {
    super.initState();
    _checkStage2Unlocked();

    _backgroundController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _bannerGlowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _footerFadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..forward();

    _footerPulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _backgroundController.dispose();
    _glowController.dispose();
    _bannerGlowController.dispose();
    _footerFadeController.dispose();
    _footerPulseController.dispose();
    nameController.dispose();
    super.dispose();
  }

  Future<void> _checkStage2Unlocked() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isStage2Unlocked = prefs.getBool('stage2_unlocked') ?? false;
    });
  }

  Future<void> _unlockStage2() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('stage2_unlocked', true);
    setState(() {
      isStage2Unlocked = true;
    });
  }

  Widget buildAdBanner({required bool isTop}) {
    return ConstrainedBox(
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.9,
      ),
      child: Container(
        margin: EdgeInsets.only(
          left: 16,
          right: 16,
          top: isTop ? 32 : 8,
          bottom: isTop ? 8 : 16,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: isTop ? Colors.transparent : null,
          gradient: isTop
              ? null
              : LinearGradient(
                  colors: [
                    Colors.deepPurple.withOpacity(0.7),
                    Colors.cyan.withOpacity(0.7)
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          boxShadow: [
            BoxShadow(
              color: Colors.cyanAccent
                  .withOpacity(0.5 + 0.3 * _bannerGlowController.value),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 3),
            ),
          ],
          border: Border.all(
            color: Colors.cyanAccent.withOpacity(0.5),
            width: 2,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.star,
                    color: Colors.white,
                    size: 24,
                  ),
                  const SizedBox(width: 10),
                  Flexible(
                    child: AnimatedBuilder(
                      animation: _bannerGlowController,
                      builder: (context, child) {
                        return ScaleTransition(
                          scale: Tween(begin: 0.95, end: 1.0).animate(
                            CurvedAnimation(
                              parent: _bannerGlowController,
                              curve: Curves.easeInOut,
                            ),
                          ),
                          child: NeonText(
                            text: isTop
                                ? "🌌 Join the rebellion to conquer space! 🚀"
                                : "🚀✨ Place Your Cool Ads Here! ✨🚀",
                            style: GoogleFonts.pressStart2p(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 1,
                            ),
                            glowColor:
                                isTop ? Colors.pinkAccent : Colors.cyanAccent,
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildFooter() {
    return FadeTransition(
      opacity: _footerFadeController,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: AnimatedBuilder(
          animation: _footerPulseController,
          builder: (context, child) {
            return Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.cyanAccent.withOpacity(0.7),
                  width: 2,
                ),
                gradient: LinearGradient(
                  colors: [
                    Colors.purpleAccent.withOpacity(0.3),
                    Colors.cyanAccent.withOpacity(0.3),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.cyanAccent
                        .withOpacity(0.5 + 0.3 * _footerPulseController.value),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ShaderMask(
                shaderCallback: (bounds) {
                  return LinearGradient(
                    colors: [
                      Colors.cyanAccent,
                      Colors.pinkAccent,
                      Colors.purpleAccent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    tileMode: TileMode.mirror,
                  ).createShader(bounds);
                },
                child: Text(
                  "Designed with ❤️ by Mcpraise 2025",
                  style: GoogleFonts.vt323(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        color: Colors.cyanAccent.withOpacity(0.8),
                        blurRadius: 10,
                        offset: Offset(0, 0),
                      ),
                      Shadow(
                        color: Colors.pinkAccent.withOpacity(0.6),
                        blurRadius: 20,
                        offset: Offset(0, 0),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: AnimatedBuilder(
          animation: _backgroundController,
          builder: (context, child) {
            return AppBar(
              title: NeonText(
                text: "TARGET BLAST",
                style: GoogleFonts.pressStart2p(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                glowColor: Colors.cyanAccent,
              ),
              backgroundColor: Colors.transparent,
              elevation: 0,
              flexibleSpace: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.black,
                      Color.fromARGB(255, 20, 0, 50),
                      Color.fromARGB(255, 10, 0, 30),
                      Colors.black,
                    ],
                    stops: [
                      0,
                      0.3 + 0.1 * sin(_backgroundController.value * 2 * pi),
                      0.7 + 0.1 * sin(_backgroundController.value * 2 * pi + 1),
                      1
                    ],
                  ),
                ),
              ),
              iconTheme: const IconThemeData(color: Colors.white),
              actions: [
                IconButton(
                  icon: ShakeWidget(
                    child: const Text('🏆', style: TextStyle(fontSize: 28)),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation, secondaryAnimation) =>
                            LeaderboardScreen(),
                        transitionsBuilder:
                            (context, animation, secondaryAnimation, child) {
                          const begin = Offset(1.0, 0.0);
                          const end = Offset.zero;
                          const curve = Curves.easeInOut;
                          var tween = Tween(begin: begin, end: end)
                              .chain(CurveTween(curve: curve));
                          return SlideTransition(
                            position: animation.drive(tween),
                            child: child,
                          );
                        },
                      ),
                    );
                  },
                ),
              ],
            );
          },
        ),
      ),
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _backgroundController,
          builder: (context, child) {
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.black,
                    Color.fromARGB(255, 20, 0, 50),
                    Color.fromARGB(255, 10, 0, 30),
                    Colors.black,
                  ],
                  stops: [
                    0,
                    0.3 + 0.1 * sin(_backgroundController.value * 2 * pi),
                    0.7 + 0.1 * sin(_backgroundController.value * 2 * pi + 1),
                    1
                  ],
                ),
              ),
              child: Stack(
                children: [
                  CustomPaint(
                    painter: StarfieldPainter(150),
                    size: Size.infinite,
                  ),
                  Column(
                    children: [
                      buildAdBanner(isTop: true),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const SizedBox(height: 20),
                                AnimatedBuilder(
                                  animation: _glowController,
                                  builder: (context, child) {
                                    return Text(
                                      "TARGET BLAST",
                                      style: GoogleFonts.pressStart2p(
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                        shadows: [
                                          BoxShadow(
                                            color: Colors.cyanAccent
                                                .withOpacity(0.3 +
                                                    0.7 *
                                                        _glowController.value),
                                            blurRadius:
                                                20 * _glowController.value,
                                            spreadRadius:
                                                2 * _glowController.value,
                                          ),
                                          BoxShadow(
                                            color: Colors.blueAccent
                                                .withOpacity(0.5 *
                                                    _glowController.value),
                                            blurRadius: 10,
                                            spreadRadius: 1,
                                          )
                                        ],
                                      ),
                                    );
                                  },
                                ),
                                const SizedBox(height: 40),
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Colors.cyanAccent,
                                      width: 2,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color:
                                            Colors.cyanAccent.withOpacity(0.3),
                                        blurRadius: 10,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                    color: Colors.black.withOpacity(0.7),
                                  ),
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 5),
                                  child: TextField(
                                    controller: nameController,
                                    style: GoogleFonts.vt323(
                                      color: Colors.greenAccent,
                                      fontSize: 22,
                                      letterSpacing: 2,
                                    ),
                                    decoration: InputDecoration(
                                      labelText: "ENTER CODENAME",
                                      labelStyle: GoogleFonts.vt323(
                                        color:
                                            Colors.cyanAccent.withOpacity(0.7),
                                        fontSize: 20,
                                      ),
                                      border: InputBorder.none,
                                      prefixIcon: const Icon(
                                        Icons.person_outlined,
                                        color: Colors.cyanAccent,
                                        size: 26,
                                      ),
                                      focusedBorder: InputBorder.none,
                                      enabledBorder: InputBorder.none,
                                    ),
                                    cursorColor: Colors.greenAccent,
                                    cursorWidth: 5,
                                    cursorRadius: const Radius.circular(2),
                                  ),
                                ),
                                const SizedBox(height: 20),
                                ArcadeButton(
                                  onPressed: () {
                                    String name = nameController.text.trim();
                                    if (name.isNotEmpty) {
                                      setState(() {
                                        playerName = name;
                                      });
                                      if (name == "rarehybrid456mcadmin") {
                                        _unlockStage2();
                                        _showUnlockAnimation();
                                      }
                                    } else {
                                      showDialog(
                                        context: context,
                                        builder: (_) => const ArcadeDialog(
                                          title: "IDENTIFY YOURSELF",
                                          content:
                                              "ENTER A CODENAME TO BEGIN MISSION.",
                                        ),
                                      );
                                    }
                                  },
                                  text: "SUBMIT",
                                  color: Colors.cyanAccent,
                                ),
                                const SizedBox(height: 30),
                                if (playerName.isNotEmpty) ...[
                                  Text(
                                    "WELCOME, ${playerName.toUpperCase()}",
                                    style: GoogleFonts.vt323(
                                      fontSize: 24,
                                      color: Colors.greenAccent,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  ArcadeButton(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        PageRouteBuilder(
                                          pageBuilder: (context, animation,
                                                  secondaryAnimation) =>
                                              GameScreen(
                                                  playerName: playerName),
                                          transitionsBuilder: (context,
                                              animation,
                                              secondaryAnimation,
                                              child) {
                                            const begin = Offset(0.0, 1.0);
                                            const end = Offset.zero;
                                            var tween = Tween(
                                                    begin: begin, end: end)
                                                .chain(CurveTween(
                                                    curve: Curves.easeInOut));
                                            return SlideTransition(
                                              position: animation.drive(tween),
                                              child: child,
                                            );
                                          },
                                        ),
                                      );
                                    },
                                    text: "STAGE 1:\nEMOJI BLAST",
                                    color: Colors.greenAccent,
                                    icon: Icons.rocket_launch,
                                  ),
                                  const SizedBox(height: 15),
                                  ArcadeButton(
                                    onPressed: isStage2Unlocked
                                        ? () {
                                            Navigator.push(
                                              context,
                                              PageRouteBuilder(
                                                pageBuilder: (context,
                                                        animation,
                                                        secondaryAnimation) =>
                                                    GameScreenSpace(
                                                        playerName: playerName),
                                                transitionsBuilder: (context,
                                                    animation,
                                                    secondaryAnimation,
                                                    child) {
                                                  const begin =
                                                      Offset(0.0, 1.0);
                                                  const end = Offset.zero;
                                                  var tween = Tween(
                                                          begin: begin,
                                                          end: end)
                                                      .chain(CurveTween(
                                                          curve: Curves
                                                              .easeInOut));
                                                  return SlideTransition(
                                                    position:
                                                        animation.drive(tween),
                                                    child: child,
                                                  );
                                                },
                                              ),
                                            );
                                          }
                                        : null,
                                    text:
                                        "STAGE 2:\nSPACE INVADERS${isStage2Unlocked ? '' : ' (LOCKED)'}",
                                    color: isStage2Unlocked
                                        ? Colors.purpleAccent
                                        : Colors.grey.withOpacity(0.5),
                                    icon: Icons.block,
                                  ),
                                  const SizedBox(height: 20),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ),
                      buildFooter(),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _showUnlockAnimation() {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      transitionDuration: const Duration(milliseconds: 500),
      pageBuilder: (context, anim1, anim2) {
        return UnlockAnimation(
          onFinish: () {
            Navigator.of(context).pop();
          },
        );
      },
    );
  }
}

class StarfieldPainter extends CustomPainter {
  final int starCount;
  final List<Offset> stars = [];
  final List<double> starSizes = [];
  final List<Color> starColors = [];

  StarfieldPainter(this.starCount) {
    final random = Random();
    for (int i = 0; i < starCount; i++) {
      stars.add(Offset(
        random.nextDouble() * 1000,
        random.nextDouble() * 2000,
      ));
      starSizes.add(random.nextDouble() * 2 + 0.5);
      final colorSet = [
        Colors.white,
        Colors.white70,
        Colors.cyanAccent.withOpacity(0.7),
        Colors.blueAccent.withOpacity(0.5),
        Colors.purpleAccent.withOpacity(0.4),
      ];
      starColors.add(colorSet[random.nextInt(colorSet.length)]);
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (int i = 0; i < stars.length; i++) {
      final paint = Paint()
        ..color = starColors[i]
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 0.5);
      if (i % 7 == 0) {
        final now = DateTime.now().millisecondsSinceEpoch / 1000;
        final twinkle = 0.15 * (1 + sin(now * 2 + i)) + 0.7;
        paint.color = paint.color.withOpacity(twinkle.clamp(0.0, 1.0));
      }
      canvas.drawCircle(
          Offset(stars[i].dx % size.width, stars[i].dy % size.height),
          starSizes[i],
          paint);
    }
    final nebulaPath1 = Path()
      ..moveTo(0, size.height * 0.3)
      ..quadraticBezierTo(size.width * 0.4, size.height * 0.1, size.width * 0.8,
          size.height * 0.4)
      ..quadraticBezierTo(
          size.width * 0.9, size.height * 0.5, size.width, size.height * 0.3)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    final nebulaPaint1 = Paint()
      ..shader = RadialGradient(
        center: Alignment.topRight,
        radius: 1.2,
        colors: [
          Colors.purpleAccent.withOpacity(0.05),
          Colors.deepPurple.withOpacity(0.02),
          Colors.transparent,
        ],
        stops: const [0.1, 0.4, 0.8],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(nebulaPath1, nebulaPaint1);
    final nebulaPath2 = Path()
      ..moveTo(size.width, size.height * 0.7)
      ..quadraticBezierTo(size.width * 0.6, size.height * 0.8, size.width * 0.3,
          size.height * 0.6)
      ..quadraticBezierTo(
          size.width * 0.1, size.height * 0.5, 0, size.height * 0.8)
      ..lineTo(0, 0)
      ..lineTo(size.width, 0)
      ..close();
    final nebulaPaint2 = Paint()
      ..shader = RadialGradient(
        center: Alignment.bottomLeft,
        radius: 1.0,
        colors: [
          Colors.blueAccent.withOpacity(0.05),
          Colors.blue.withOpacity(0.02),
          Colors.transparent,
        ],
        stops: const [0.1, 0.4, 0.8],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(nebulaPath2, nebulaPaint2);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ArcadeButton extends StatefulWidget {
  final VoidCallback? onPressed;
  final String text;
  final Color color;
  final IconData? icon;

  const ArcadeButton({
    Key? key,
    this.onPressed,
    required this.text,
    required this.color,
    this.icon,
  }) : super(key: key);

  @override
  _ArcadeButtonState createState() => _ArcadeButtonState();
}

class _ArcadeButtonState extends State<ArcadeButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isEnabled = widget.onPressed != null;

    return GestureDetector(
      onTapDown: (details) {
        if (!isEnabled) return;
        setState(() {
          _isPressed = true;
        });
        _controller.forward();
      },
      onTapUp: (details) {
        if (!isEnabled) return;
        setState(() {
          _isPressed = false;
        });
        _controller.reverse();
        widget.onPressed?.call();
      },
      onTapCancel: () {
        if (!isEnabled) return;
        setState(() {
          _isPressed = false;
        });
        _controller.reverse();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Container(
            width: 300,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: widget.color.withOpacity(isEnabled ? 1.0 : 0.3),
                width: 2,
              ),
              boxShadow: isEnabled
                  ? [
                      BoxShadow(
                        color: widget.color
                            .withOpacity(0.5 - 0.3 * _controller.value),
                        blurRadius: 15 * (1 - _controller.value),
                        spreadRadius: 1,
                        offset: Offset(0, 5 * (1 - _controller.value)),
                      ),
                    ]
                  : [],
            ),
            transform: Matrix4.translationValues(0, _controller.value * 5, 0),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.icon != null) ...[
                      Icon(
                        widget.icon,
                        color: widget.color.withOpacity(isEnabled ? 1.0 : 0.5),
                        size: 18,
                      ),
                      const SizedBox(height: 4),
                    ],
                    Text(
                      widget.text,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.pressStart2p(
                        color: widget.color.withOpacity(isEnabled ? 1.0 : 0.5),
                        fontSize: 9,
                        letterSpacing: 1,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class NeonText extends StatelessWidget {
  final String text;
  final TextStyle style;
  final Color glowColor;

  const NeonText({
    Key? key,
    required this.text,
    required this.style,
    this.glowColor = Colors.white,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: style.copyWith(
        shadows: [
          Shadow(
            color: glowColor.withOpacity(0.8),
            blurRadius: 10,
          ),
          Shadow(
            color: glowColor.withOpacity(0.5),
            blurRadius: 20,
          ),
        ],
      ),
    );
  }
}

class ArcadeDialog extends StatelessWidget {
  final String title;
  final String content;

  const ArcadeDialog({
    Key? key,
    required this.title,
    required this.content,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      child: Container(
        width: 300,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: Colors.cyanAccent,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.cyanAccent.withOpacity(0.3),
              blurRadius: 15,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            NeonText(
              text: title,
              style: GoogleFonts.pressStart2p(
                fontSize: 16,
                color: Colors.white,
              ),
              glowColor: Colors.cyanAccent,
            ),
            const SizedBox(height: 20),
            Text(
              content,
              textAlign: TextAlign.center,
              style: GoogleFonts.vt323(
                fontSize: 20,
                color: Colors.greenAccent,
              ),
            ),
            const SizedBox(height: 20),
            ArcadeButton(
              onPressed: () => Navigator.pop(context),
              text: "OK",
              color: Colors.cyanAccent,
            ),
          ],
        ),
      ),
    );
  }
}

class ShakeWidget extends StatefulWidget {
  final Widget child;
  final Duration duration;
  final double deltaX;

  const ShakeWidget({
    Key? key,
    required this.child,
    this.duration = const Duration(milliseconds: 800),
    this.deltaX = 5.0,
  }) : super(key: key);

  @override
  _ShakeWidgetState createState() => _ShakeWidgetState();
}

class _ShakeWidgetState extends State<ShakeWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.duration,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final sineValue = sin(2 * pi * _controller.value);
        return Transform.translate(
          offset: Offset(sineValue * widget.deltaX, 0),
          child: child,
        );
      },
      child: widget.child,
    );
  }
}

class UnlockAnimation extends StatefulWidget {
  final VoidCallback onFinish;

  const UnlockAnimation({Key? key, required this.onFinish}) : super(key: key);

  @override
  _UnlockAnimationState createState() => _UnlockAnimationState();
}

class _UnlockAnimationState extends State<UnlockAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..forward().then((_) => widget.onFinish());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Container(
            color: Colors.black.withOpacity(0.9),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ScaleTransition(
                    scale: Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(
                      parent: _controller,
                      curve: Interval(0.0, 0.5, curve: Curves.elasticOut),
                    )),
                    child: ShaderMask(
                      shaderCallback: (bounds) {
                        return LinearGradient(
                          colors: [
                            Colors.purple,
                            Colors.deepPurple,
                            Colors.purple,
                          ],
                          stops: [0.0, 0.5, 1.0],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          tileMode: TileMode.mirror,
                        ).createShader(bounds);
                      },
                      child: Text(
                        "STAGE 2 UNLOCKED!",
                        style: GoogleFonts.pressStart2p(
                          fontSize: 20,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                              color: Colors.purpleAccent,
                              blurRadius: 20,
                              offset: Offset(0, 0),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  FadeTransition(
                    opacity:
                        Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(
                      parent: _controller,
                      curve: Interval(0.5, 0.8, curve: Curves.easeIn),
                    )),
                    child: Text(
                      "SPACE INVADERS MODE",
                      style: GoogleFonts.vt323(
                        fontSize: 30,
                        color: Colors.greenAccent,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 60),
                  FadeTransition(
                    opacity:
                        Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(
                      parent: _controller,
                      curve: Interval(0.7, 1.0, curve: Curves.easeIn),
                    )),
                    child: Text(
                      "👾 👾 👾",
                      style: TextStyle(fontSize: 40),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
