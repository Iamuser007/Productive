import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math';

class LeaderboardScreen extends StatefulWidget {
  @override
  _LeaderboardScreenState createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen>
    with TickerProviderStateMixin {
  List<Map<String, dynamic>> scores = [];
  late AnimationController _glowController;
  late AnimationController _backgroundController;
  final List<AnimationController> _podiumControllers = [];

  @override
  void initState() {
    super.initState();
    loadScores();

    // Initialize animation controllers
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _backgroundController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    // Create controllers for top 3 podium animations
    for (int i = 0; i < 3; i++) {
      _podiumControllers.add(AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 800 + i * 200),
      ));
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final args = ModalRoute.of(context)?.settings.arguments;
      if (args is Map &&
          args.containsKey('playerName') &&
          args.containsKey('score')) {
        updateLeaderboard(args['playerName'] as String, args['score'] as int);
      }

      // Start podium animations after frame is built
      for (var controller in _podiumControllers) {
        controller.forward();
      }
    });
  }

  @override
  void dispose() {
    _glowController.dispose();
    _backgroundController.dispose();
    for (var controller in _podiumControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> loadScores() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> rawScores = prefs.getStringList('scores') ?? [];

    // Convert to Map format for easier handling
    List<Map<String, dynamic>> parsedScores = [];
    for (String score in rawScores) {
      List<String> parts = score.split(": ");
      if (parts.length == 2) {
        parsedScores.add({
          'playerName': parts[0],
          'score': int.parse(parts[1]),
        });
      }
    }

    setState(() {
      scores = parsedScores;
    });
  }

  Future<void> updateLeaderboard(String playerName, int score) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> currentRawScores = prefs.getStringList('scores') ?? [];

    // Convert to Map format
    List<Map<String, dynamic>> currentScores = [];
    for (String scoreStr in currentRawScores) {
      List<String> parts = scoreStr.split(": ");
      if (parts.length == 2) {
        currentScores.add({
          'playerName': parts[0],
          'score': int.parse(parts[1]),
        });
      }
    }

    // Check if player already exists
    bool playerExists = false;
    for (int i = 0; i < currentScores.length; i++) {
      if (currentScores[i]['playerName'] == playerName) {
        playerExists = true;
        // Update score only if new score is higher
        if (score > currentScores[i]['score']) {
          currentScores[i]['score'] = score;
        }
        break;
      }
    }

    // Add new player if they don't exist
    if (!playerExists) {
      currentScores.add({
        'playerName': playerName,
        'score': score,
      });
    }

    // Sort by score
    currentScores.sort((a, b) => b['score'].compareTo(a['score']));

    // Keep top 5
    if (currentScores.length > 5) {
      currentScores = currentScores.sublist(0, 5);
    }

    // Convert back to string format for storage
    List<String> updatedScores = currentScores
        .map((item) => "${item['playerName']}: ${item['score']}")
        .toList();

    await prefs.setStringList('scores', updatedScores);
    loadScores(); // Refresh
  }

  Widget _buildLeaderboardItem(int index, Map<String, dynamic> scoreData) {
    final bool isTopThree = index < 3;
    final Color itemColor = isTopThree
        ? [Colors.amber, Colors.grey.shade300, Colors.brown.shade300][index]
        : Colors.blueGrey.shade100;

    // Medal emojis for top 3
    final String medal =
        isTopThree ? ['🏆', '🥈', '🥉'][index] : "#${index + 1}";

    if (isTopThree) {
      return AnimatedBuilder(
        animation: _podiumControllers[index],
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, 50 * (1 - _podiumControllers[index].value)),
            child: Opacity(
              opacity: _podiumControllers[index].value,
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      itemColor.withOpacity(0.7),
                      itemColor.withOpacity(0.2),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: itemColor
                          .withOpacity(0.5 + 0.2 * _glowController.value),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Text(
                            medal,
                            style: TextStyle(fontSize: 28),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                NeonText(
                                  text: scoreData['playerName'],
                                  style: GoogleFonts.pressStart2p(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                  glowColor: [
                                    Colors.amber,
                                    Colors.blueAccent,
                                    Colors.purpleAccent
                                  ][index],
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "Score: ${scoreData['score']}",
                                  style: GoogleFonts.vt323(
                                    fontSize: 22,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      );
    } else {
      // Regular leaderboard item
      return Container(
        margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.7),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: Colors.cyanAccent.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              Container(
                width: 36,
                child: Text(
                  medal,
                  style: GoogleFonts.vt323(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      scoreData['playerName'],
                      style: GoogleFonts.vt323(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.greenAccent,
                      ),
                    ),
                    Text(
                      "Score: ${scoreData['score']}",
                      style: GoogleFonts.vt323(
                        fontSize: 16,
                        color: Colors.cyanAccent,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: NeonText(
          text: "TOP PILOTS",
          style: GoogleFonts.pressStart2p(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          glowColor: Colors.cyanAccent,
        ),
        leading: IconButton(
          icon: ShakeWidget(
            child: const Text('⬅️', style: TextStyle(fontSize: 28)),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: AnimatedBuilder(
        animation: _backgroundController,
        builder: (context, child) {
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.black,
                  Color.fromARGB(255, 20, 0, 50),
                  Color.fromARGB(255, 10, 0, 30),
                  Colors.black,
                ],
                stops: [
                  0,
                  0.3 + 0.1 * sin(_backgroundController.value * 2 * pi),
                  0.7 + 0.1 * sin(_backgroundController.value * 2 * pi + 1),
                  1
                ],
              ),
            ),
            child: Stack(
              children: [
                CustomPaint(
                  painter: StarfieldPainter(150),
                  size: Size.infinite,
                ),
                SafeArea(
                  child: scores.isEmpty
                      ? Center(
                          child: NeonText(
                            text: "NO SCORES YET!",
                            style: GoogleFonts.pressStart2p(
                              fontSize: 16,
                              color: Colors.white,
                            ),
                            glowColor: Colors.redAccent,
                          ),
                        )
                      : ListView.builder(
                          padding: EdgeInsets.only(top: 16),
                          itemCount: scores.length,
                          itemBuilder: (context, index) {
                            return _buildLeaderboardItem(index, scores[index]);
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class StarfieldPainter extends CustomPainter {
  final int starCount;
  final List<Offset> stars = [];
  final List<double> starSizes = [];
  final List<Color> starColors = [];

  StarfieldPainter(this.starCount) {
    final random = Random();
    for (int i = 0; i < starCount; i++) {
      stars.add(Offset(
        random.nextDouble() * 1000,
        random.nextDouble() * 2000,
      ));
      starSizes.add(random.nextDouble() * 2 + 0.5);
      final colorSet = [
        Colors.white,
        Colors.white70,
        Colors.cyanAccent.withOpacity(0.7),
        Colors.blueAccent.withOpacity(0.5),
        Colors.purpleAccent.withOpacity(0.4),
      ];
      starColors.add(colorSet[random.nextInt(colorSet.length)]);
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (int i = 0; i < stars.length; i++) {
      final paint = Paint()
        ..color = starColors[i]
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 0.5);
      if (i % 7 == 0) {
        final now = DateTime.now().millisecondsSinceEpoch / 1000;
        final twinkle = 0.3 * (1 + sin(now * 2 + i)) + 0.7;
        paint.color = paint.color.withOpacity(twinkle);
      }
      canvas.drawCircle(
          Offset(stars[i].dx % size.width, stars[i].dy % size.height),
          starSizes[i],
          paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class NeonText extends StatelessWidget {
  final String text;
  final TextStyle style;
  final Color glowColor;

  const NeonText({
    Key? key,
    required this.text,
    required this.style,
    this.glowColor = Colors.white,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: style.copyWith(
        shadows: [
          Shadow(
            color: glowColor.withOpacity(0.8),
            blurRadius: 10,
          ),
          Shadow(
            color: glowColor.withOpacity(0.5),
            blurRadius: 20,
          ),
        ],
      ),
    );
  }
}

class ShakeWidget extends StatefulWidget {
  final Widget child;
  final Duration duration;
  final double deltaX;

  const ShakeWidget({
    Key? key,
    required this.child,
    this.duration = const Duration(milliseconds: 800),
    this.deltaX = 5.0,
  }) : super(key: key);

  @override
  _ShakeWidgetState createState() => _ShakeWidgetState();
}

class _ShakeWidgetState extends State<ShakeWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.duration,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final sineValue = sin(2 * pi * _controller.value);
        return Transform.translate(
          offset: Offset(sineValue * widget.deltaX, 0),
          child: child,
        );
      },
      child: widget.child,
    );
  }
}
