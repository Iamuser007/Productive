import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'MainScreen.dart';

class Laser {
  final Offset start;
  final Offset end;
  final bool isPlayerLaser;
  final double speed;
  double progress = 0.0;

  Laser(this.start, this.end, this.isPlayerLaser, this.speed);

  bool get isComplete => progress >= 1.0;

  void update(double dt) {
    progress += speed * dt;
    if (progress > 1.0) progress = 1.0;
  }

  Offset get currentPosition {
    return Offset(
      start.dx + (end.dx - start.dx) * progress,
      start.dy + (end.dy - start.dy) * progress,
    );
  }
}

class Enemy {
  Offset position;
  double size;
  bool isDestroyed = false;
  Timer? shootTimer;
  bool movingLeft = true;
  double speed = 8.0; // Faster enemy movement

  Enemy(this.position, this.size);
}

class PreloaderScreen extends StatefulWidget {
  const PreloaderScreen({super.key});

  @override
  _PreloaderScreenState createState() => _PreloaderScreenState();
}

class _PreloaderScreenState extends State<PreloaderScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final Random _random = Random();
  double _progress = 0.0;

  // Player ship properties
  late Offset _playerPosition;
  double _playerSize = 40.0;
  bool _movingLeft = false;
  bool _movingRight = true;
  bool _playerDestroyed = false;
  double _playerSpeed = 8.0; // Faster player movement

  // Enemy
  late Enemy _enemy;

  // Lasers
  List<Laser> _lasers = [];

  // Stars for background
  List<Offset> _stars = [];
  List<double> _starSizes = [];
  List<double> _starSpeeds = [];
  List<Color> _starColors = [];

  // Explosions
  List<Offset> _explosions = [];
  List<double> _explosionTimes = [];

  // Game state
  bool _gameOver = false;
  Timer? _navigationTimer;

  // Shooting timers
  Timer? _playerShootTimer;
  int _playerScore = 0;
  int _enemyScore = 0;

  @override
  void initState() {
    super.initState();

    // Initialize controller
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 16),
    )..addListener(_updateGame);

    // Start the game loop
    _controller.repeat();

    // Generate stars with varied colors and speeds
    for (int i = 0; i < 150; i++) {
      _stars.add(Offset(
        _random.nextDouble() * 400,
        _random.nextDouble() * 800,
      ));
      _starSizes.add(_random.nextDouble() * 3 + 1);
      _starSpeeds.add(_random.nextDouble() * 2 + 1);
      _starColors.add([
        Colors.white,
        Colors.blue[200]!,
        Colors.purpleAccent[100]!,
        Colors.yellowAccent[100]!,
        Colors.cyanAccent[100]!
      ][_random.nextInt(5)]);
    }

    // Initialize player position at bottom
    _playerPosition = const Offset(200, 700);

    // Create single enemy at top
    _enemy = Enemy(const Offset(200, 100), 40.0);

    // Setup aggressive shooting for both
    _setupShooting();

    // Auto navigate to main screen after 10 seconds
    _navigationTimer =
        Timer(const Duration(seconds: 10), _navigateToMainScreen);
  }

  void _navigateToMainScreen() {
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MainScreen()),
      );
    }
  }

  void _setupShooting() {
    // Enemy shoots every 300-500ms
    _enemy.shootTimer =
        Timer.periodic(const Duration(milliseconds: 300), (timer) {
      if (!_enemy.isDestroyed && mounted) {
        setState(() {
          _lasers.add(Laser(
            _enemy.position,
            Offset(_enemy.position.dx, 800),
            false,
            1.5, // Faster lasers
          ));
        });
      } else {
        timer.cancel();
      }
    });

    // Player shoots every 300ms
    _playerShootTimer =
        Timer.periodic(const Duration(milliseconds: 300), (timer) {
      if (!_playerDestroyed && mounted) {
        setState(() {
          _lasers.add(Laser(
            Offset(_playerPosition.dx, _playerPosition.dy - 20),
            Offset(_playerPosition.dx, 0),
            true,
            1.8, // Even faster player lasers
          ));
        });
      }
    });
  }

  void _updateGame() {
    if (!mounted || _gameOver) return;

    setState(() {
      // Update progress bar (0 to 100% in 10 seconds)
      _progress = min(1.0, _progress + 0.00167);

      // Update star positions for scrolling effect
      for (int i = 0; i < _stars.length; i++) {
        _stars[i] = Offset(
          _stars[i].dx,
          _stars[i].dy + _starSpeeds[i],
        );
        if (_stars[i].dy > 800) {
          _stars[i] = Offset(
            _random.nextDouble() * 400,
            0,
          );
          _starSpeeds[i] = _random.nextDouble() * 2 + 1;
        }
      }

      // Move player aggressively if not destroyed
      if (!_playerDestroyed) {
        if (_movingRight) {
          _playerPosition = Offset(
              min(_playerPosition.dx + _playerSpeed, 360), _playerPosition.dy);
          if (_playerPosition.dx >= 360) {
            _movingRight = false;
            _movingLeft = true;
          }
        } else if (_movingLeft) {
          _playerPosition = Offset(
              max(_playerPosition.dx - _playerSpeed, 40), _playerPosition.dy);
          if (_playerPosition.dx <= 40) {
            _movingLeft = false;
            _movingRight = true;
          }
        }
      }

      // Move enemy aggressively
      if (!_enemy.isDestroyed) {
        if (_enemy.movingLeft) {
          _enemy.position = Offset(
              max(_enemy.position.dx - _enemy.speed, 40), _enemy.position.dy);
          if (_enemy.position.dx <= 40) {
            _enemy.movingLeft = false;
          }
        } else {
          _enemy.position = Offset(
              min(_enemy.position.dx + _enemy.speed, 360), _enemy.position.dy);
          if (_enemy.position.dx >= 360) {
            _enemy.movingLeft = true;
          }
        }

        // Add some vertical movement too for more dynamic feel
        _enemy.position =
            Offset(_enemy.position.dx, 100 + sin(_controller.value * 30) * 30);
      }

      // Update lasers and check collisions
      List<int> lasersToRemove = [];

      for (int i = 0; i < _lasers.length; i++) {
        _lasers[i].update(0.016);

        if (_lasers[i].isComplete) {
          lasersToRemove.add(i);
          continue;
        }

        if (_lasers[i].isPlayerLaser) {
          // Check for player laser hitting enemy
          if (!_enemy.isDestroyed &&
              (_lasers[i].currentPosition - _enemy.position).distance <
                  _enemy.size / 2) {
            _enemy.isDestroyed = true;
            _explosions.add(_enemy.position);
            _explosionTimes.add(0.0);
            lasersToRemove.add(i);
            _playerScore++;

            // Respawn enemy after destruction
            Timer(const Duration(milliseconds: 800), () {
              if (mounted) {
                setState(() {
                  _enemy.isDestroyed = false;
                  _enemy.position = Offset(
                    _random.nextDouble() * 320 + 40,
                    100,
                  );
                  // Randomize direction after respawn
                  _enemy.movingLeft = _random.nextBool();
                  // Increase speed slightly each time
                  _enemy.speed = min(_enemy.speed + 0.5, 15.0);
                });
              }
            });
          }
        } else {
          // Check for enemy laser hitting player
          if (!_playerDestroyed &&
              (_lasers[i].currentPosition - _playerPosition).distance <
                  _playerSize / 2) {
            _playerDestroyed = true;
            _explosions.add(_playerPosition);
            _explosionTimes.add(0.0);
            lasersToRemove.add(i);
            _enemyScore++;

            // Respawn player after destruction
            Timer(const Duration(milliseconds: 800), () {
              if (mounted) {
                setState(() {
                  _playerDestroyed = false;
                  // Randomize start direction after respawn
                  _movingRight = _random.nextBool();
                  _movingLeft = !_movingRight;
                  // Increase speed slightly each time
                  _playerSpeed = min(_playerSpeed + 0.5, 15.0);
                });
              }
            });
          }
        }
      }

      // Remove lasers in reverse order to avoid index issues
      lasersToRemove.sort((a, b) => b.compareTo(a));
      for (int index in lasersToRemove) {
        if (index < _lasers.length) {
          _lasers.removeAt(index);
        }
      }

      // Update explosions
      for (int i = _explosionTimes.length - 1; i >= 0; i--) {
        _explosionTimes[i] += 0.05;
        if (_explosionTimes[i] > 1.0) {
          _explosions.removeAt(i);
          _explosionTimes.removeAt(i);
        }
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _enemy.shootTimer?.cancel();
    _playerShootTimer?.cancel();
    _navigationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Starfield with nebula effect
          CustomPaint(
            painter: StarfieldPainter(_stars, _starSizes, _starColors),
            size: Size.infinite,
          ),

          // Game elements
          CustomPaint(
            painter: GamePainter(
              _playerPosition,
              _playerSize,
              _playerDestroyed,
              _enemy,
              _lasers,
              _explosions,
              _explosionTimes,
            ),
            size: Size.infinite,
          ),

          // Score display
          Positioned(
            top: 40,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "$_playerScore : $_enemyScore",
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),

          // Loading text and progress bar
          Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Column(
              children: [
                const Text(
                  "TARGET BLAST",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.cyanAccent,
                    letterSpacing: 4,
                    shadows: [
                      Shadow(
                        color: Colors.blueAccent,
                        blurRadius: 15,
                        offset: Offset(0, 0),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: LinearProgressIndicator(
                      value: _progress,
                      backgroundColor: Colors.grey[900],
                      valueColor: const AlwaysStoppedAnimation<Color>(
                          Colors.cyanAccent),
                      minHeight: 18,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "${(_progress * 100).toInt()}%",
                  style: const TextStyle(
                    color: Colors.cyanAccent,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class StarfieldPainter extends CustomPainter {
  final List<Offset> stars;
  final List<double> starSizes;
  final List<Color> starColors;

  StarfieldPainter(this.stars, this.starSizes, this.starColors);

  @override
  void paint(Canvas canvas, Size size) {
    // Draw nebula background
    final nebulaPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.blue[900]!.withOpacity(0.3),
          Colors.purple[900]!.withOpacity(0.3),
          Colors.black.withOpacity(0.1),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), nebulaPaint);

    // Draw stars
    for (int i = 0; i < stars.length; i++) {
      final paint = Paint()
        ..color = starColors[i]
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
      canvas.drawCircle(stars[i], starSizes[i], paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class GamePainter extends CustomPainter {
  final Offset playerPosition;
  final double playerSize;
  final bool playerDestroyed;
  final Enemy enemy;
  final List<Laser> lasers;
  final List<Offset> explosions;
  final List<double> explosionTimes;

  GamePainter(
    this.playerPosition,
    this.playerSize,
    this.playerDestroyed,
    this.enemy,
    this.lasers,
    this.explosions,
    this.explosionTimes,
  );

  @override
  void paint(Canvas canvas, Size size) {
    // Draw player ship if not destroyed
    if (!playerDestroyed) {
      final playerPaint = Paint()..color = Colors.cyan;
      final Path playerPath = Path();
      playerPath.moveTo(playerPosition.dx, playerPosition.dy - playerSize / 2);
      playerPath.lineTo(playerPosition.dx + playerSize / 2,
          playerPosition.dy + playerSize / 2);
      playerPath.lineTo(playerPosition.dx - playerSize / 2,
          playerPosition.dy + playerSize / 2);
      playerPath.close();
      canvas.drawPath(playerPath, playerPaint);

      // Player emoji
      TextPainter(
        text: const TextSpan(
          text: '🚀',
          style: TextStyle(fontSize: 40),
        ),
        textDirection: TextDirection.ltr,
      )
        ..layout()
        ..paint(
            canvas,
            Offset(playerPosition.dx - 20,
                playerPosition.dy - playerSize / 2 - 20));

      // Draw engine glow with pulse
      final engineGlowPaint = Paint()
        ..color = Colors.cyanAccent.withOpacity(
            0.8 + 0.2 * sin(DateTime.now().millisecondsSinceEpoch / 200))
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);

      canvas.drawCircle(
        Offset(playerPosition.dx, playerPosition.dy + playerSize / 3),
        playerSize / 3,
        engineGlowPaint,
      );
    }

    // Draw enemy
    if (!enemy.isDestroyed) {
      final enemyPaint = Paint()..color = Colors.redAccent;

      // Enemy ship body
      canvas.drawCircle(enemy.position, enemy.size / 2, enemyPaint);

      // Enemy emoji
      TextPainter(
        text: const TextSpan(
          text: '👾',
          style: TextStyle(fontSize: 40),
        ),
        textDirection: TextDirection.ltr,
      )
        ..layout()
        ..paint(
            canvas,
            Offset(enemy.position.dx - 20,
                enemy.position.dy - enemy.size / 2 - 20));

      // Enemy glow
      final enemyGlowPaint = Paint()
        ..color = Colors.redAccent.withOpacity(
            0.6 + 0.3 * sin(DateTime.now().millisecondsSinceEpoch / 150))
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 15);

      canvas.drawCircle(
        enemy.position,
        enemy.size / 3,
        enemyGlowPaint,
      );
    }

    // Draw lasers
    for (var laser in lasers) {
      final laserPaint = Paint()
        ..color = laser.isPlayerLaser ? Colors.cyanAccent : Colors.redAccent
        ..strokeWidth = 4.0
        ..style = PaintingStyle.stroke;

      canvas.drawLine(
        laser.start,
        laser.currentPosition,
        laserPaint,
      );

      final glowPaint = Paint()
        ..color = (laser.isPlayerLaser ? Colors.cyanAccent : Colors.redAccent)
            .withOpacity(0.7)
        ..strokeWidth = 10.0
        ..style = PaintingStyle.stroke
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);

      canvas.drawLine(
        laser.start,
        laser.currentPosition,
        glowPaint,
      );
    }

    // Draw explosions
    for (int i = 0; i < explosions.length; i++) {
      final t = explosionTimes[i];
      final radius = 50 * t;
      final opacity = 1.0 - t;

      final explosionPaint = Paint()
        ..color = Colors.orangeAccent.withOpacity(opacity)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(explosions[i], radius, explosionPaint);

      final ringPaint = Paint()
        ..color = Colors.yellow.withOpacity(opacity * 0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4.0;

      canvas.drawCircle(explosions[i], radius * 0.7, ringPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class TargetBlastApp extends StatelessWidget {
  const TargetBlastApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Target Blast',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const PreloaderScreen(),
    );
  }
}
