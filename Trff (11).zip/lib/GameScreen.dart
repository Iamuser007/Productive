import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'LeaderboardScreen.dart';
import 'RainBackground.dart';
import 'emoji_effects.dart';
import 'power_up_manager.dart';
import 'MainScreen.dart';

class GameScreen extends StatefulWidget {
  final String playerName;

  GameScreen({required this.playerName});

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  int score = 0;
  int lives = 3;
  Offset targetPosition = Offset(100, 100);
  Timer? targetTimer;
  bool gameOver = false;
  AudioPlayer audioPlayer = AudioPlayer();
  AudioPlayer bgmPlayer = AudioPlayer();
  List<String> emojis = [
    '🎯',
    '💥',
    '🔥',
    '🎉',
    '⭐',
    '🍀',
    '💣',
    '🚀',
    '👾',
    '💚',
    '🐢'
  ];

  int tortoisePowerUpCount = 0;
  int lemonHeartPowerUpCount = 0;
  bool powerUpMenuOpen = false;

  late AnimationController _rainController;
  late AnimationController _bombShakeController;
  late Animation<double> _shakeAnimation;
  bool _emojiVisible = true;
  String currentEmoji = '🎯';
  bool stageCompleted = false;

  int baseSpeed = 1000;
  int currentSpeed = 1000;

  // Snowflake power-up state
  bool isSnowflakeMode = false;
  List<Offset> snowflakePositions = [];
  List<bool> snowflakeVisible = [];

  late EmojiEffects emojiEffects;
  late PowerUpManager powerUpManager;

  late AnimationController _popupController;
  late Animation<double> _popupAnimation;

  @override
  void initState() {
    super.initState();
    emojiEffects = EmojiEffects(this);
    powerUpManager = PowerUpManager();
    startGame();

    _rainController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2),
    )..repeat();

    _bombShakeController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );

    _shakeAnimation = Tween<double>(begin: 0, end: 10).animate(
      CurvedAnimation(parent: _bombShakeController, curve: Curves.elasticIn),
    );

    _popupController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    );

    _popupAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _popupController, curve: Curves.easeInOut),
    );

    playBackgroundMusic();
  }

  void playBackgroundMusic() async {
    await bgmPlayer.setReleaseMode(ReleaseMode.loop);
    await bgmPlayer.play(AssetSource("bgm.mp3"));
  }

  @override
  void dispose() {
    targetTimer?.cancel();
    _rainController.dispose();
    _bombShakeController.dispose();
    _popupController.dispose();
    audioPlayer.dispose();
    bgmPlayer.dispose();
    emojiEffects.dispose();
    super.dispose();
  }

  void startGame() {
    score = 0;
    lives = 3;
    gameOver = false;
    tortoisePowerUpCount = 0;
    lemonHeartPowerUpCount = 0;
    stageCompleted = false;
    isSnowflakeMode = false;
    snowflakePositions.clear();
    snowflakeVisible.clear();
    currentSpeed = baseSpeed;
    moveTarget();
  }

  void moveTarget() {
    targetTimer?.cancel();

    int delay = getTargetMoveDelay(score);

    targetTimer = Timer.periodic(Duration(milliseconds: delay), (timer) {
      if (gameOver || stageCompleted || isSnowflakeMode) {
        timer.cancel();
        return;
      }

      setState(() {
        double x = Random().nextDouble() * 300;
        double y = Random().nextDouble() * 500;
        targetPosition = Offset(x, y);

        if (score < 30 && Random().nextDouble() < 0.1) {
          currentEmoji = '🐢';
        } else if (score < 50 && Random().nextDouble() < 0.1) {
          currentEmoji = '💚';
        } else if (Random().nextDouble() < 0.1) {
          currentEmoji = '💣';
        } else {
          currentEmoji = emojis[Random()
              .nextInt(emojis.length - 3)]; // Exclude bomb, heart, tortoise
        }

        _emojiVisible = true;
      });
    });
  }

  int getTargetMoveDelay(int currentScore) {
    int baseDelay = currentSpeed;
    int decrement = (currentScore ~/ 10) * 75;
    return (baseDelay - decrement).clamp(200, baseDelay);
  }

  Future<void> _unlockStage2() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('stage2_unlocked', true);
    print('Stage 2 unlocked in SharedPreferences');
  }

  void _showStageCompletePopup() {
    print('Showing stage complete popup');
    _popupController.forward();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AnimatedBuilder(
        animation: _popupAnimation,
        builder: (context, child) => Transform.scale(
          scale: _popupAnimation.value,
          child: AlertDialog(
            backgroundColor: Colors.black.withOpacity(0.9),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Stage 1 Completed! 🎉',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Score: $score',
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                SizedBox(height: 10),
                Text(
                  'Stage 2 Unlocked!',
                  style: TextStyle(
                    color: Colors.greenAccent,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            actions: [
              Builder(
                builder: (context) => TextButton(
                  onPressed: () async {
                    print('Continue button pressed');
                    await _unlockStage2();
                    if (!mounted) return;
                    print('Navigating to MainScreen');
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const MainScreen()),
                      (route) => false,
                    );
                  },
                  child: Text(
                    'Continue',
                    style: TextStyle(color: Colors.cyan, fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void hitTarget() async {
    if (gameOver || !_emojiVisible || stageCompleted || isSnowflakeMode) return;

    setState(() {
      _emojiVisible = false;
    });

    HapticFeedback.mediumImpact();

    String emoji = currentEmoji;

    emojiEffects.createScatterEffect(targetPosition, emoji);

    moveTarget();

    if (emoji == '💣') {
      _bombShakeController.forward(from: 0);
      setState(() {
        lives--;
        if (lives <= 0) {
          gameOver = true;
          saveScore(widget.playerName, score);
        }
      });
    } else if (emoji == '💚') {
      if (lemonHeartPowerUpCount < 3) {
        setState(() => lemonHeartPowerUpCount++);
      }
    } else if (emoji == '🐢') {
      if (tortoisePowerUpCount < 3) {
        setState(() => tortoisePowerUpCount++);
      }
    } else if (emoji == '🔥') {
      setState(() => score += 5);
      await playSound();
    } else {
      setState(() => score += 3);
      await playSound();
    }

    if (score >= 120 && !stageCompleted) {
      stageCompleted = true;
      await saveScore(widget.playerName, score);
      if (!mounted) return;
      _showStageCompletePopup();
    }
  }

  void useTortoisePowerUp() {
    if (tortoisePowerUpCount > 0 && !isSnowflakeMode) {
      setState(() {
        tortoisePowerUpCount--;
        currentSpeed = baseSpeed;
        isSnowflakeMode = true;
        snowflakePositions.clear();
        snowflakeVisible.clear();

        // Generate 10 snowflakes at random positions
        for (int i = 0; i < 10; i++) {
          double x = Random().nextDouble() * 300;
          double y = Random().nextDouble() * 500;
          snowflakePositions.add(Offset(x, y));
          snowflakeVisible.add(true);
        }
      });

      // Pause the game
      targetTimer?.cancel();

      // Resume game after 5 seconds
      Timer(Duration(seconds: 5), () {
        if (!mounted) return;
        setState(() {
          isSnowflakeMode = false;
          snowflakePositions.clear();
          snowflakeVisible.clear();
        });
        moveTarget();
      });
    }
  }

  void hitSnowflake(int index) async {
    if (!snowflakeVisible[index]) return;

    setState(() {
      snowflakeVisible[index] = false;
      score += 2;
    });

    await playSound();
    emojiEffects.createScatterEffect(snowflakePositions[index], '❄️');

    if (score >= 120 && !stageCompleted) {
      stageCompleted = true;
      await saveScore(widget.playerName, score);
      if (!mounted) return;
      _showStageCompletePopup();
    }
  }

  void useLemonHeartPowerUp() {
    if (lemonHeartPowerUpCount > 0 && lives < 3) {
      setState(() {
        lemonHeartPowerUpCount--;
        lives++;
      });
    }
  }

  Future<void> playSound() async {
    await audioPlayer.play(AssetSource('g.mp3'));
  }

  Future<void> saveScore(String playerName, int score) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> scores = prefs.getStringList('scores') ?? [];
    scores.add('$playerName: $score');
    scores.sort((a, b) =>
        int.parse(b.split(": ")[1]).compareTo(int.parse(a.split(": ")[1])));
    if (scores.length > 5) scores = scores.sublist(0, 5);
    await prefs.setStringList('scores', scores);
  }

  Widget getLifeIcons() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        lives,
        (index) => Icon(Icons.favorite, color: Colors.red, size: 24),
      ),
    );
  }

  Widget getPowerUpSection() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        ElevatedButton(
          onPressed: () {
            setState(() {
              powerUpMenuOpen = !powerUpMenuOpen;
            });
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue[700],
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          ),
          child: Text("PowerUps", style: TextStyle(color: Colors.white)),
        ),
        if (powerUpMenuOpen)
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.9),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (tortoisePowerUpCount > 0)
                  GestureDetector(
                    onTap: useTortoisePowerUp,
                    child: Padding(
                      padding: EdgeInsets.all(4),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('🐢', style: TextStyle(fontSize: 24)),
                          SizedBox(width: 4),
                          Text('x$tortoisePowerUpCount',
                              style: TextStyle(fontSize: 16)),
                          SizedBox(width: 4),
                          Text('Snowflake Bonus',
                              style: TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                if (lemonHeartPowerUpCount > 0)
                  GestureDetector(
                    onTap: useLemonHeartPowerUp,
                    child: Padding(
                      padding: EdgeInsets.all(4),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('💚', style: TextStyle(fontSize: 24)),
                          SizedBox(width: 4),
                          Text('x$lemonHeartPowerUpCount',
                              style: TextStyle(fontSize: 16)),
                          SizedBox(width: 4),
                          Text('Restore Health',
                              style: TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final shakeOffset = _shakeAnimation.value;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.leaderboard),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => LeaderboardScreen()),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _rainController,
            builder: (context, child) {
              return RainBackground(progress: _rainController.value);
            },
          ),
          ...emojiEffects.buildParticles(),
          if (!gameOver && !stageCompleted && !isSnowflakeMode)
            Positioned(
              left: targetPosition.dx,
              top: targetPosition.dy,
              child: GestureDetector(
                onTap: hitTarget,
                child: AnimatedOpacity(
                  duration: Duration(milliseconds: 200),
                  opacity: _emojiVisible ? 1.0 : 0.0,
                  child: Transform.translate(
                    offset: currentEmoji == '💣'
                        ? Offset(sin(shakeOffset) * 5, 0)
                        : Offset.zero,
                    child: Container(
                      width: 60,
                      height: 60,
                      child: Center(
                        child:
                            Text(currentEmoji, style: TextStyle(fontSize: 40)),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          // Snowflake emojis
          if (isSnowflakeMode)
            ...List.generate(snowflakePositions.length, (index) {
              return Positioned(
                left: snowflakePositions[index].dx,
                top: snowflakePositions[index].dy,
                child: GestureDetector(
                  onTap: () => hitSnowflake(index),
                  child: AnimatedOpacity(
                    duration: Duration(milliseconds: 200),
                    opacity: snowflakeVisible[index] ? 1.0 : 0.0,
                    child: Container(
                      width: 60,
                      height: 60,
                      child: Center(
                        child: Text('❄️', style: TextStyle(fontSize: 40)),
                      ),
                    ),
                  ),
                ),
              );
            }),
          Positioned(
            top: 16,
            left: 16,
            child: Text("Score: $score",
                style: TextStyle(fontSize: 24, color: Colors.black)),
          ),
          Positioned(
            top: 16,
            right: 16,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                getLifeIcons(),
                SizedBox(height: 8),
                getPowerUpSection(),
              ],
            ),
          ),
          if (gameOver)
            Center(
              child: Container(
                padding: EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.95),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text("Game Over", style: TextStyle(fontSize: 32)),
                    SizedBox(height: 10),
                    Text("Score: $score", style: TextStyle(fontSize: 24)),
                    SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              startGame();
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                          ),
                          child: Text("Play Again"),
                        ),
                        SizedBox(width: 10),
                        ElevatedButton(
                          onPressed: () {
                            print('Back to Menu button pressed');
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const MainScreen()),
                              (route) => false,
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[900],
                            foregroundColor: Colors.white,
                          ),
                          child: Text("Back to Menu"),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
