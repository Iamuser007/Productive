import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'styles.dart';

class GameScreenSpace extends StatefulWidget {
  final String playerName;

  const GameScreenSpace({Key? key, required this.playerName}) : super(key: key);

  @override
  GameScreenSpaceState createState() => GameScreenSpaceState();
}

class GameScreenSpaceState extends State<GameScreenSpace>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  // Player properties
  double playerX = 0.0;
  double playerWidth = 0.0;
  double playerHeight = 0.0;
  int lives = 3;
  bool hasShield = false;
  int multipleBulletsCount = 0;
  double pointsMultiplier = 1.0;

  // Powerup inventory
  Map<PowerUpType, int> powerUpInventory = {
    PowerUpType.health: 0,
    PowerUpType.multipleBullets: 0,
    PowerUpType.shield: 0,
    PowerUpType.pointsMultiplier: 0,
  };
  Map<PowerUpType, Timer?> powerUpTimers = {};

  // Game area
  double screenWidth = 0.0;
  double screenHeight = 0.0;
  final double gameAreaPadding = 10.0;

  // Game state
  bool gameStarted = false;
  int score = 0;
  int highScore = 0;
  int wave = 1;

  // Game objects
  List<Missile> playerMissiles = [];
  List<Missile> enemyMissiles = [];
  List<Enemy> enemies = [];
  List<Shield> shields = [];
  List<PowerUp> powerUps = [];
  List<SymbolParticle> symbolParticles = [];
  List<Explosion> explosions = [];

  // Game settings
  int enemyCount = 1;
  final int maxEnemies = 4;
  int enemyDirection = 1;
  double enemySpeed = 2.0;
  double enemyShootInterval = 1000;
  int enemyDamage = 1;

  // Timers
  Timer? gameTimer;
  Timer? enemyShootTimer;
  Timer? enemyMovementTimer;
  Timer? powerUpTimer;

  // Audio
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isMusicPlaying = false;
  final Map<String, String> soundAssets = {
    'background': 'bgm.mp3',
    'player_shoot': 'player_shoot.mp3',
    'bot_shoot': 'bot_shoot.mp3',
    'bot_destroy': 'enemy_hit.mp3',
    'powerup_collect': 'powerup.mp3',
    'powerup_activate': 'powerup_activate.mp3',
    'player_hit': 'player_hit.mp3',
    'game_over': 'game_over.mp3',
    'wave_start': 'wave_start.mp3',
  };

  // Animations
  late AnimationController _symbolRainController;
  late AnimationController _gameOverController;

  // Dropdown state
  PowerUpType? _selectedPowerUp;

  @override
  void initState() {
    super.initState();
    _symbolRainController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();
    _gameOverController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    WidgetsBinding.instance.addObserver(this);

    // Initialize screen dimensions and player size
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        screenWidth = MediaQuery.of(context).size.width;
        screenHeight = MediaQuery.of(context).size.height * 0.75;
        playerWidth = screenWidth * 0.06;
        playerHeight = screenWidth * 0.06;
        playerX = screenWidth / 2 - playerWidth / 2;
        createShields();
        createSymbolParticles();
      });
      _playBackgroundMusic();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.paused) {
      if (_isMusicPlaying) {
        _audioPlayer.pause();
        _isMusicPlaying = false;
      }
    } else if (state == AppLifecycleState.resumed) {
      if (!_isMusicPlaying && gameStarted) {
        _playBackgroundMusic();
      }
    }
  }

  void _playBackgroundMusic() async {
    if (!_isMusicPlaying) {
      await _audioPlayer.setSource(AssetSource(soundAssets['background']!));
      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      await _audioPlayer.resume();
      _isMusicPlaying = true;
    }
  }

  void _stopBackgroundMusic() async {
    if (_isMusicPlaying) {
      await _audioPlayer.stop();
      _isMusicPlaying = false;
    }
  }

  void _playSound(String key) async {
    final player = AudioPlayer();
    await player.play(AssetSource(soundAssets[key]!));
  }

  void showFlashMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(color: GameStyles.textColor),
          textAlign: TextAlign.center,
        ),
        backgroundColor: Colors.black87,
        duration: Duration(seconds: 1),
        padding: EdgeInsets.symmetric(vertical: 10),
      ),
    );
  }

  void startGame() {
    if (gameStarted) return;
    setState(() {
      gameStarted = true;
      score = 0;
      lives = 3;
      wave = 1;
      enemyCount = 1;
      enemySpeed = 2.0;
      enemyShootInterval = 1000;
      enemyDamage = 1;
      playerMissiles.clear();
      enemyMissiles.clear();
      powerUps.clear();
      powerUpInventory.updateAll((key, value) => 0);
      hasShield = false;
      multipleBulletsCount = 0;
      pointsMultiplier = 1.0;
      _selectedPowerUp = null;
    });
    _playSound('wave_start');
    createEnemies();
    createShields();
    gameTimer = Timer.periodic(const Duration(milliseconds: 16), (timer) {
      updateGame();
    });
    enemyShootTimer = Timer.periodic(
        Duration(milliseconds: enemyShootInterval.toInt()), (timer) {
      enemyShoot();
    });
    enemyMovementTimer =
        Timer.periodic(const Duration(milliseconds: 400), (timer) {
      moveEnemies();
    });
    powerUpTimer = Timer.periodic(const Duration(seconds: 10), (timer) {});
  }

  void createEnemies() {
    enemies.clear();
    double enemyWidth = screenWidth * 0.08;
    double enemyHeight = screenWidth * 0.06;
    double spacingX = screenWidth * 0.04;
    double startX = (screenWidth - (enemyCount * (enemyWidth + spacingX))) / 2;
    double startY = screenHeight * 0.1;
    for (int i = 0; i < enemyCount; i++) {
      enemies.add(Enemy(
        x: startX + i * (enemyWidth + spacingX),
        y: startY,
        width: enemyWidth,
        height: enemyHeight,
        type: i % 3,
      ));
    }
  }

  void createShields() {
    shields.clear();
    double shieldWidth = screenWidth * 0.12;
    double spacing = (screenWidth - (3 * shieldWidth)) / 4;
    double yPosition = screenHeight - screenWidth * 0.3;
    for (int i = 0; i < 3; i++) {
      double xPosition = spacing + i * (shieldWidth + spacing);
      for (int row = 0; row < 3; row++) {
        for (int col = 0; col < 3; col++) {
          if (row == 2 && col == 1) continue;
          shields.add(Shield(
            x: xPosition + col * (shieldWidth / 3),
            y: yPosition + row * (shieldWidth / 3),
            width: shieldWidth / 3,
            height: shieldWidth / 3,
            health: 3,
          ));
        }
      }
    }
  }

  void createSymbolParticles() {
    symbolParticles.clear();
    final random = Random();
    const symbols = ['0', '1', '#', '@', '%', '&'];
    for (int i = 0; i < 50; i++) {
      symbolParticles.add(SymbolParticle(
        x: random.nextDouble() * screenWidth,
        y: random.nextDouble() * screenHeight,
        symbol: symbols[random.nextInt(symbols.length)],
        speed: random.nextDouble() * 2 + 1,
      ));
    }
  }

  void spawnPowerUp(double x, double y) {
    if (!gameStarted) return;
    final random = Random();
    final types = [
      PowerUpType.health,
      PowerUpType.multipleBullets,
      PowerUpType.shield,
      PowerUpType.pointsMultiplier,
    ];
    powerUps.add(PowerUp(
      x: x,
      y: y,
      width: screenWidth * 0.06,
      height: screenWidth * 0.06,
      type: types[random.nextInt(types.length)],
    ));
  }

  void updateGame() {
    if (!gameStarted) return;
    setState(() {
      updateMissiles();
      updatePowerUps();
      updateSymbolParticles();
      updateExplosions();
      checkCollisions();
      if (enemies.isEmpty) {
        nextWave();
      }
      if (lives <= 0 || isPlayerInvaded()) {
        endGame();
      }
    });
  }

  void updateMissiles() {
    for (int i = playerMissiles.length - 1; i >= 0; i--) {
      playerMissiles[i].y -= 10;
      if (playerMissiles[i].y < 0) {
        playerMissiles.removeAt(i);
      }
    }
    for (int i = enemyMissiles.length - 1; i >= 0; i--) {
      var missile = enemyMissiles[i];
      missile.y += missile.dy ?? 5;
      missile.x += missile.dx ?? 0;
      if (missile.y > screenHeight ||
          missile.x < 0 ||
          missile.x > screenWidth) {
        enemyMissiles.removeAt(i);
      }
    }
  }

  void updatePowerUps() {
    for (int i = powerUps.length - 1; i >= 0; i--) {
      powerUps[i].y += 2;
      if (powerUps[i].y > screenHeight) {
        powerUps.removeAt(i);
      }
    }
  }

  void updateSymbolParticles() {
    for (var particle in symbolParticles) {
      particle.y += particle.speed;
      if (particle.y > screenHeight) {
        particle.y = -20;
        particle.x = Random().nextDouble() * screenWidth;
      }
    }
  }

  void updateExplosions() {
    for (int i = explosions.length - 1; i >= 0; i--) {
      explosions[i].scale += 0.05;
      explosions[i].opacity -= 0.05;
      if (explosions[i].opacity <= 0) {
        explosions.removeAt(i);
      }
    }
  }

  void moveEnemies() {
    if (!gameStarted) return;
    bool shouldChangeDirection = false;
    for (var enemy in enemies) {
      if ((enemyDirection > 0 &&
              enemy.x + enemy.width + enemySpeed >
                  screenWidth - gameAreaPadding) ||
          (enemyDirection < 0 && enemy.x - enemySpeed < gameAreaPadding)) {
        shouldChangeDirection = true;
        break;
      }
    }
    setState(() {
      if (shouldChangeDirection) {
        enemyDirection *= -1;
      }
      for (var enemy in enemies) {
        enemy.x += enemyDirection * enemySpeed;
      }
    });
  }

  bool isPlayerInvaded() {
    for (var enemy in enemies) {
      if (enemy.y + enemy.height > screenHeight - playerHeight - 20) {
        return true;
      }
    }
    return false;
  }

  void enemyShoot() {
    if (!gameStarted || enemies.isEmpty) return;
    final random = Random();
    final shooter = enemies[random.nextInt(enemies.length)];
    setState(() {
      double dx = playerX - shooter.x;
      double dy = (screenHeight - playerHeight - 20) - shooter.y;
      double angle = atan2(dy, dx);
      enemyMissiles.add(Missile(
        x: shooter.x + shooter.width / 2 - 2,
        y: shooter.y + shooter.height,
        width: 4,
        height: 15,
        isEnemy: true,
        dx: cos(angle) * 5,
        dy: sin(angle) * 5,
      ));
      _playSound('bot_shoot');
    });
  }

  void playerShoot() {
    if (!gameStarted) return;
    _playSound('player_shoot');
    setState(() {
      if (multipleBulletsCount > 0) {
        playerMissiles.addAll([
          Missile(
            x: playerX + playerWidth / 2 - 2,
            y: screenHeight - playerHeight - 20,
            width: 4,
            height: 15,
            isEnemy: false,
          ),
          Missile(
            x: playerX + playerWidth / 2 - 8,
            y: screenHeight - playerHeight - 20,
            width: 4,
            height: 15,
            isEnemy: false,
          ),
          Missile(
            x: playerX + playerWidth / 2 + 4,
            y: screenHeight - playerHeight - 20,
            width: 4,
            height: 15,
            isEnemy: false,
          ),
        ]);
        multipleBulletsCount--;
      } else {
        playerMissiles.add(Missile(
          x: playerX + playerWidth / 2 - 2,
          y: screenHeight - playerHeight - 20,
          width: 4,
          height: 15,
          isEnemy: false,
        ));
      }
    });
  }

  void checkCollisions() {
    for (int i = playerMissiles.length - 1; i >= 0; i--) {
      var missile = playerMissiles[i];
      bool hitSomething = false;
      for (int j = enemies.length - 1; j >= 0; j--) {
        var enemy = enemies[j];
        if (missile.x + missile.width > enemy.x &&
            missile.x < enemy.x + enemy.width &&
            missile.y < enemy.y + enemy.height &&
            missile.y + missile.height > enemy.y) {
          enemies.removeAt(j);
          hitSomething = true;
          score += ((enemy.type + 1) * 10 * pointsMultiplier).toInt();
          _playSound('bot_destroy');
          explosions.add(Explosion(x: enemy.x, y: enemy.y));
          spawnPowerUp(enemy.x, enemy.y);
          break;
        }
      }
      if (!hitSomething) {
        for (int j = shields.length - 1; j >= 0; j--) {
          var shield = shields[j];
          if (missile.x + missile.width > shield.x &&
              missile.x < shield.x + shield.width &&
              missile.y < shield.y + shield.height &&
              missile.y + missile.height > shield.y) {
            shield.health--;
            if (shield.health <= 0) shields.removeAt(j);
            hitSomething = true;
            break;
          }
        }
      }
      if (hitSomething) {
        playerMissiles.removeAt(i);
      }
    }

    for (int i = enemyMissiles.length - 1; i >= 0; i--) {
      var missile = enemyMissiles[i];
      bool hitSomething = false;
      if (missile.x + missile.width > playerX &&
          missile.x < playerX + playerWidth &&
          missile.y + missile.height > screenHeight - playerHeight - 20 &&
          missile.y < screenHeight - 20) {
        if (!hasShield) {
          lives -= enemyDamage;
          _playSound('player_hit');
        } else {
          hasShield = false;
        }
        hitSomething = true;
      }
      if (!hitSomething) {
        for (int j = shields.length - 1; j >= 0; j--) {
          var shield = shields[j];
          if (missile.x + missile.width > shield.x &&
              missile.x < shield.x + shield.width &&
              missile.y + missile.height > shield.y &&
              missile.y < shield.y + shield.height) {
            shield.health--;
            if (shield.health <= 0) shields.removeAt(j);
            hitSomething = true;
            break;
          }
        }
      }
      if (hitSomething) {
        enemyMissiles.removeAt(i);
      }
    }

    for (int i = powerUps.length - 1; i >= 0; i--) {
      var powerUp = powerUps[i];
      if (powerUp.x + powerUp.width > playerX &&
          powerUp.x < playerX + playerWidth &&
          powerUp.y + powerUp.height > screenHeight - playerHeight - 20 &&
          powerUp.y < screenHeight - 20) {
        if (powerUpInventory[powerUp.type]! < 3) {
          powerUpInventory[powerUp.type] = powerUpInventory[powerUp.type]! + 1;
          _playSound('powerup_collect');
          showFlashMessage(
              '${powerUp.type.toString().split('.').last} claimed!');
        }
        powerUps.removeAt(i);
      }
    }
  }

  void activatePowerUp(PowerUpType? type) {
    if (type == null || powerUpInventory[type] == 0) return;
    setState(() {
      powerUpInventory[type] = powerUpInventory[type]! - 1;
      _playSound('powerup_activate');
      showFlashMessage('${type.toString().split('.').last} activated!');
      _selectedPowerUp = null;
      switch (type) {
        case PowerUpType.health:
          lives = (lives + 1).clamp(0, 3);
          break;
        case PowerUpType.multipleBullets:
          multipleBulletsCount += 10;
          powerUpTimers[type]?.cancel();
          powerUpTimers[type] = Timer(const Duration(seconds: 15), () {
            setState(() {
              multipleBulletsCount = 0;
            });
          });
          break;
        case PowerUpType.shield:
          hasShield = true;
          powerUpTimers[type]?.cancel();
          powerUpTimers[type] = Timer(const Duration(seconds: 15), () {
            setState(() {
              hasShield = false;
            });
          });
          break;
        case PowerUpType.pointsMultiplier:
          pointsMultiplier = 2.0;
          powerUpTimers[type]?.cancel();
          powerUpTimers[type] = Timer(const Duration(seconds: 15), () {
            setState(() {
              pointsMultiplier = 1.0;
            });
          });
          break;
      }
    });
  }

  void nextWave() {
    wave++;
    enemyCount = (enemyCount + 1).clamp(1, maxEnemies);
    enemySpeed += 0.5;
    enemyShootInterval = (enemyShootInterval * 0.8).clamp(400, 1000);
    enemyDamage = wave >= 5 ? 2 : 1;
    enemyShootTimer?.cancel();
    enemyShootTimer = Timer.periodic(
        Duration(milliseconds: enemyShootInterval.toInt()), (timer) {
      enemyShoot();
    });
    _playSound('wave_start');
    createEnemies();
  }

  Future<void> saveScore(String playerName, int score) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> scores = prefs.getStringList('scores') ?? [];
    scores.add('$playerName: $score');
    scores.sort((a, b) =>
        int.parse(b.split(": ")[1]).compareTo(int.parse(a.split(": ")[1])));
    if (scores.length > 5) scores = scores.sublist(0, 5);
    await prefs.setStringList('scores', scores);
  }

  void endGame() {
    _playSound('game_over');
    gameStarted = false;
    gameTimer?.cancel();
    enemyShootTimer?.cancel();
    enemyMovementTimer?.cancel();
    powerUpTimer?.cancel();
    powerUpTimers.values.forEach((timer) => timer?.cancel());
    highScore = score > highScore ? score : highScore;

    // Save score to leaderboard
    saveScore(widget.playerName, score);

    _gameOverController.forward(from: 0);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => GameOverAnimation(
        controller: _gameOverController,
        child: AlertDialog(
          backgroundColor: Colors.transparent,
          contentPadding: EdgeInsets.zero,
          content: Container(
            decoration: GameStyles.gameOverDialog,
            padding: EdgeInsets.all(screenWidth * 0.05),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Game Over', style: GameStyles.gameOverTitle(screenWidth)),
                SizedBox(height: screenWidth * 0.03),
                Text('Score: $score\nHigh Score: $highScore',
                    style: GameStyles.gameOverContent(screenWidth),
                    textAlign: TextAlign.center),
                SizedBox(height: screenWidth * 0.05),
                ElevatedButton(
                  style: GameStyles.actionButton(screenWidth),
                  onPressed: () {
                    Navigator.pop(context);
                    startGame();
                  },
                  child: Text('Play Again'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void movePlayer(double dx) {
    setState(() {
      playerX += dx;
      playerX = playerX.clamp(
          gameAreaPadding, screenWidth - playerWidth - gameAreaPadding);
    });
  }

  @override
  void dispose() {
    gameTimer?.cancel();
    enemyShootTimer?.cancel();
    enemyMovementTimer?.cancel();
    powerUpTimer?.cancel();
    powerUpTimers.values.forEach((timer) => timer?.cancel());
    _stopBackgroundMusic();
    _audioPlayer.dispose();
    _symbolRainController.dispose();
    _gameOverController.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GameStyles.backgroundColor,
      appBar: AppBar(
        title:
            Text('SPACE INVADERS', style: GameStyles.titleStyle(screenWidth)),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          // Update dimensions in case of resize
          screenWidth = constraints.maxWidth;
          screenHeight = constraints.maxHeight * 0.75;
          playerWidth = screenWidth * 0.06;
          playerHeight = screenWidth * 0.06;
          return Column(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.05,
                    vertical: screenWidth * 0.02),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'SCORE: $score  WAVE: $wave',
                      style: GameStyles.scoreStyle(screenWidth),
                    ),
                    Row(
                      children: List.generate(
                        3,
                        (index) => Padding(
                          padding: EdgeInsets.only(left: screenWidth * 0.02),
                          child: Icon(
                            Icons.favorite,
                            color: index < lives
                                ? Colors.red
                                : Colors.grey.shade800,
                            size: screenWidth * 0.06,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                child: Theme(
                  data: Theme.of(context).copyWith(
                    dropdownMenuTheme: GameStyles.powerUpDropdownTheme,
                  ),
                  child: DropdownButton<PowerUpType>(
                    hint: Row(
                      children: [
                        Icon(Icons.power,
                            color: GameStyles.accentColor,
                            size: screenWidth * 0.05),
                        SizedBox(width: screenWidth * 0.02),
                        Text(
                          'Power-Ups',
                          style: TextStyle(
                              color: GameStyles.textColor,
                              fontSize: screenWidth * 0.04),
                        ),
                      ],
                    ),
                    dropdownColor: Colors.black87,
                    value: _selectedPowerUp,
                    items: PowerUpType.values
                        .where((type) => powerUpInventory[type]! > 0)
                        .map((type) => DropdownMenuItem(
                              value: type,
                              child: Text(
                                '${type.toString().split('.').last}: ${powerUpInventory[type]}',
                                style: TextStyle(
                                    color: GameStyles.textColor,
                                    fontSize: screenWidth * 0.03),
                              ),
                            ))
                        .toList(),
                    onChanged: activatePowerUp,
                    isExpanded: false,
                    underline: Container(),
                  ),
                ),
              ),
              Expanded(
                child: GestureDetector(
                  onHorizontalDragUpdate: (details) =>
                      movePlayer(details.delta.dx),
                  onTap: gameStarted ? playerShoot : startGame,
                  child: Container(
                    color: Colors.black,
                    child: Stack(
                      children: [
                        ...symbolParticles.map((particle) => Positioned(
                              left: particle.x,
                              top: particle.y,
                              child: Text(
                                particle.symbol,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.3),
                                  fontSize: screenWidth * 0.035,
                                ),
                              ),
                            )),
                        ...shields.map((shield) => Positioned(
                              left: shield.x,
                              top: shield.y,
                              child: Container(
                                width: shield.width,
                                height: shield.height,
                                color: shield.health == 3
                                    ? Colors.green
                                    : (shield.health == 2
                                        ? Colors.lightGreen
                                        : Colors.lightGreen.withOpacity(0.5)),
                              ),
                            )),
                        Positioned(
                          left: playerX,
                          bottom: screenWidth * 0.08,
                          child: AnimatedContainer(
                            duration: Duration(milliseconds: 200),
                            width: playerWidth +
                                (hasShield ? screenWidth * 0.02 : 0),
                            height: playerHeight +
                                (hasShield ? screenWidth * 0.02 : 0),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: hasShield
                                  ? GameStyles.shieldColor.withOpacity(0.3)
                                  : Colors.transparent,
                            ),
                            child: Center(
                              child: Text(
                                '🚀',
                                style: TextStyle(fontSize: playerWidth),
                              ),
                            ),
                          ),
                        ),
                        ...enemies.map((enemy) => Positioned(
                              left: enemy.x,
                              top: enemy.y,
                              child: Text(
                                enemy.type == 0
                                    ? '👾'
                                    : enemy.type == 1
                                        ? '🦑'
                                        : '🐙',
                                style: TextStyle(fontSize: enemy.width),
                              ),
                            )),
                        ...playerMissiles.map((missile) => Positioned(
                              left: missile.x,
                              top: missile.y,
                              child: Container(
                                width: missile.width,
                                height: missile.height,
                                color: GameStyles.accentColor,
                              ),
                            )),
                        ...enemyMissiles.map((missile) => Positioned(
                              left: missile.x,
                              top: missile.y,
                              child: Container(
                                width: missile.width,
                                height: missile.height,
                                color: Colors.red,
                              ),
                            )),
                        ...powerUps.map((powerUp) => Positioned(
                              left: powerUp.x,
                              top: powerUp.y,
                              child: AnimatedScale(
                                scale: 1.0 +
                                    sin(DateTime.now().millisecondsSinceEpoch /
                                            100) *
                                        0.1,
                                duration: Duration(milliseconds: 200),
                                child: Text(
                                  powerUp.type == PowerUpType.health
                                      ? '❤️'
                                      : powerUp.type ==
                                              PowerUpType.multipleBullets
                                          ? '🔫'
                                          : powerUp.type == PowerUpType.shield
                                              ? '🛡️'
                                              : '💰',
                                  style: TextStyle(fontSize: powerUp.width),
                                ),
                              ),
                            )),
                        ...explosions.map((explosion) => Positioned(
                              left: explosion.x,
                              top: explosion.y,
                              child: Opacity(
                                opacity: explosion.opacity,
                                child: Transform.scale(
                                  scale: explosion.scale,
                                  child: Text(
                                    '💥',
                                    style:
                                        TextStyle(fontSize: screenWidth * 0.06),
                                  ),
                                ),
                              ),
                            )),
                        if (!gameStarted && lives > 0)
                          Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'SPACE INVADERS',
                                  style: TextStyle(
                                    color: GameStyles.textColor,
                                    fontSize: screenWidth * 0.04,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: screenWidth * 0.05),
                                ElevatedButton(
                                  onPressed: startGame,
                                  style: GameStyles.actionButton(screenWidth),
                                  child: Text(
                                    'START GAME',
                                    style: TextStyle(
                                      fontSize: screenWidth * 0.045,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                SizedBox(height: screenWidth * 0.05),
                                Text(
                                  'Tap to shoot\nDrag to move',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color:
                                        GameStyles.textColor.withOpacity(0.7),
                                    fontSize: screenWidth * 0.04,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// Game objects
class Missile {
  double x;
  double y;
  final double width;
  final double height;
  final bool isEnemy;
  double? dx;
  double? dy;

  Missile({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.isEnemy,
    this.dx,
    this.dy,
  });
}

class Enemy {
  double x;
  double y;
  final double width;
  final double height;
  final int type;

  Enemy({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.type,
  });
}

class Shield {
  final double x;
  final double y;
  final double width;
  final double height;
  int health;

  Shield({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.health,
  });
}

class PowerUp {
  double x;
  double y;
  final double width;
  final double height;
  final PowerUpType type;

  PowerUp({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.type,
  });
}

enum PowerUpType { health, multipleBullets, shield, pointsMultiplier }

class SymbolParticle {
  double x;
  double y;
  final String symbol;
  final double speed;

  SymbolParticle({
    required this.x,
    required this.y,
    required this.symbol,
    required this.speed,
  });
}

class Explosion {
  double x;
  double y;
  double scale;
  double opacity;

  Explosion(
      {required this.x, required this.y, this.scale = 1.0, this.opacity = 1.0});
}

class GameOverAnimation extends StatelessWidget {
  final AnimationController controller;
  final Widget child;

  const GameOverAnimation({
    Key? key,
    required this.controller,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return Transform.scale(
          scale: Tween<double>(begin: 0.5, end: 1.0)
              .animate(
                CurvedAnimation(
                  parent: controller,
                  curve: Curves.elasticOut,
                ),
              )
              .value,
          child: Opacity(
            opacity: Tween<double>(begin: 0.0, end: 1.0)
                .animate(
                  CurvedAnimation(
                    parent: controller,
                    curve: Curves.easeIn,
                  ),
                )
                .value,
            child: child,
          ),
        );
      },
    );
  }
}
