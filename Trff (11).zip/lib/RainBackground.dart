import 'package:flutter/material.dart';
import 'dart:math';

class RainBackground extends StatefulWidget {
  final double progress;

  RainBackground({required this.progress});

  @override
  _RainBackgroundState createState() => _RainBackgroundState();
}

class _RainBackgroundState extends State<RainBackground>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late List<RainDrop> _rainDrops;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    )..repeat();
    _rainDrops = List.generate(100, (index) => RainDrop());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: RainPainter(_rainDrops),
          size: MediaQuery.of(context).size,
        );
      },
    );
  }
}

class RainDrop {
  double x;
  double y;
  double speed;

  RainDrop()
      : x = Random().nextDouble() * 400,
        y = Random().nextDouble() * 800,
        speed = 2 + Random().nextDouble() * 4;

  void update(Size size) {
    y += speed;
    if (y > size.height) {
      y = 0;
      x = Random().nextDouble() * size.width;
    }
  }
}

class RainPainter extends CustomPainter {
  final List<RainDrop> rainDrops;

  RainPainter(this.rainDrops);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue.withOpacity(0.5)
      ..strokeWidth = 2.0;

    for (final drop in rainDrops) {
      drop.update(size);
      canvas.drawLine(
        Offset(drop.x, drop.y),
        Offset(drop.x, drop.y + 20),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
