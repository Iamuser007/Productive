import 'package:flutter/material.dart';

class GameStyles {
  static const Color backgroundColor = Colors.black;
  static const Color textColor = Colors.white;
  static const Color accentColor = Colors.cyan;
  static const Color powerUpColor = Colors.yellow;
  static const Color shieldColor = Colors.blue;

  static TextStyle titleStyle(double screenWidth) => TextStyle(
        fontFamily: 'Press Start 2P',
        fontSize: screenWidth * 0.045, // Scales with screen
        color: textColor,
      );

  static TextStyle scoreStyle(double screenWidth) => TextStyle(
        color: textColor,
        fontSize: screenWidth * 0.04,
        fontWeight: FontWeight.bold,
      );

  static TextStyle gameOverTitle(double screenWidth) => TextStyle(
        color: textColor,
        fontSize: screenWidth * 0.06,
        fontWeight: FontWeight.bold,
      );

  static TextStyle gameOverContent(double screenWidth) => TextStyle(
        color: textColor.withOpacity(0.8),
        fontSize: screenWidth * 0.04,
      );

  static final BoxDecoration gameOverDialog = BoxDecoration(
    color: Colors.black87,
    border: Border.all(color: accentColor, width: 2),
    borderRadius: BorderRadius.circular(10),
  );

  static ButtonStyle actionButton(double screenWidth) =>
      ElevatedButton.styleFrom(
        backgroundColor: accentColor,
        padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.05, vertical: screenWidth * 0.03),
        textStyle: TextStyle(
            fontSize: screenWidth * 0.035, fontWeight: FontWeight.bold),
      );

  static final DropdownMenuThemeData powerUpDropdownTheme =
      DropdownMenuThemeData(
    textStyle: TextStyle(color: textColor, fontSize: 16),
    menuStyle: MenuStyle(
      backgroundColor: WidgetStateProperty.all(Colors.black87),
      elevation: WidgetStateProperty.all(8),
      shape: WidgetStateProperty.all(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: accentColor, width: 1),
        ),
      ),
    ),
  );
}

// Animation for game over popup
class GameOverAnimation extends StatelessWidget {
  final AnimationController controller;
  final Widget child;

  const GameOverAnimation({
    Key? key,
    required this.controller,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return Opacity(
          opacity: controller.value,
          child: Transform.scale(
            scale: 0.8 + controller.value * 0.2,
            child: child,
          ),
        );
      },
    );
  }
}
