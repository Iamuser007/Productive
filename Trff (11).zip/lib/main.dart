import 'dart:io';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:convert';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'preloader.dart'; // Import the PreloaderScreen for the gaming feature
import 'dart:async';

void main() => runApp(const TargetBlastApp());

class TargetBlastApp extends StatelessWidget {
  const TargetBlastApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Productivity Tools',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        // textTheme: GoogleFonts.pressStart2pTextTheme(),
        scaffoldBackgroundColor: Colors.white,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home:
          const ProductivityPreloaderScreen(), // Start with productivity preloader
    );
  }
}

class ProductivityPreloaderScreen extends StatefulWidget {
  const ProductivityPreloaderScreen({super.key});

  @override
  _ProductivityPreloaderScreenState createState() =>
      _ProductivityPreloaderScreenState();
}

class _ProductivityPreloaderScreenState
    extends State<ProductivityPreloaderScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 10), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => const HomeScreen(),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            CircularProgressIndicator(),
            SizedBox(height: 20),
            Text(
              'Bringing Productivity to Your Fingertips 🚀',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
                fontStyle: FontStyle.italic,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Text(
              'One tool at a time, making your life easier! 📱',
              style: TextStyle(
                fontSize: 16,
                fontStyle: FontStyle.italic,
                color: Colors.blueAccent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Productivity Tools 📱'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Welcome to the Productivity Tools App! 🚀',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            const Text(
              'Our goal is to bring productivity to your fingertips! 🖐️',
              style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () => _navigateToWebView(
                  context, 'https://qrgeneratorr.streamlit.app'),
              child: const Text("QR Code Generator 📱"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _navigateToWebView(
                  context, 'https://sketchpad.streamlit.app'),
              child: const Text("Sketchpad 🎨"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const TodoListPage(),
              )),
              child: const Text("Todo List Manager ✅"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const QuickNotePage(),
              )),
              child: const Text("Quick Note Taker 📝"),
            ),
            const SizedBox(height: 20),
            _AnimatedSteamButton(),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const ParticipantsPage(),
              )),
              child: const Text("Project Participants 👥"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const DocumentationPage()),
                );
              },
              child: const Text("📄 Open Documentation"),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToWebView(BuildContext context, String url) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => QRWebView(url: url),
    ));
  }
}

class _AnimatedSteamButton extends StatefulWidget {
  @override
  __AnimatedSteamButtonState createState() => __AnimatedSteamButtonState();
}

class __AnimatedSteamButtonState extends State<_AnimatedSteamButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _glowAnimation;
  late Animation<double> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _glowAnimation = Tween<double>(begin: 0.0, end: 10.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _shakeAnimation = Tween<double>(begin: -0.01, end: 0.01).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutSine),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _showCodeDialog(BuildContext context) {
    final TextEditingController codeController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Enter Secret Code'),
        content: TextField(
          controller: codeController,
          decoration: const InputDecoration(
            hintText: 'EnTeR cOdE',
            border: OutlineInputBorder(),
          ),
          keyboardType: TextInputType.number,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (codeController.text == '01017785') {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const PreloaderScreen()),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Invalid code! Try again.')),
                );
              }
            },
            child: const Text('Submit'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.rotate(
          angle: _shakeAnimation.value,
          child: Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.red.withOpacity(0.5),
                  blurRadius: _glowAnimation.value,
                  spreadRadius: _glowAnimation.value / 2,
                ),
              ],
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              ),
              onPressed: () => _showCodeDialog(context),
              child: const Text(
                'Blow Off Some Steam 🎮🔥',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ),
        );
      },
    );
  }
}

class QRWebView extends StatefulWidget {
  final String url;
  const QRWebView({super.key, required this.url});

  @override
  State<QRWebView> createState() => _QRWebViewState();
}

class _QRWebViewState extends State<QRWebView> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (NavigationRequest request) {
          final url = request.url;
          if (_isDownloadLink(url)) {
            _handleDownload(url);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(widget.url));

    _controller.addJavaScriptChannel(
      'FileUploadChannel',
      onMessageReceived: (message) {
        if (message.message == 'upload') {
          _pickFile();
        }
      },
    );
  }

  bool _isDownloadLink(String url) {
    return url.endsWith(".png") ||
        url.endsWith(".jpg") ||
        url.endsWith(".jpeg") ||
        url.endsWith(".pdf") ||
        url.contains("download=true") ||
        url.contains("media&token=");
  }

  Future<void> _handleDownload(String url) async {
    final hasPermission = await _requestStoragePermission();
    if (!hasPermission) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Storage permission denied")),
      );
      return;
    }

    try {
      final dio = Dio();
      final dir = await getExternalStorageDirectory();
      final filename = url.split('/').last.split('?').first;
      final filePath = "${dir!.path}/$filename";

      await dio.download(url, filePath);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Downloaded to: $filePath")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Download failed: $e")),
      );
    }
  }

  Future<bool> _requestStoragePermission() async {
    final status = await Permission.storage.status;
    if (status.isGranted) {
      return true;
    } else {
      final result = await Permission.storage.request();
      return result.isGranted;
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null) {
      final file = result.files.single;
      _uploadFile(file);
    }
  }

  Future<void> _uploadFile(PlatformFile file) async {
    final dio = Dio();
    final formData = FormData.fromMap({
      'file': await MultipartFile.fromFile(file.path!, filename: file.name),
    });
    try {
      final response =
          await dio.post('YOUR_STREAMLIT_UPLOAD_API', data: formData);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('File uploaded: ${response.data}')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('File upload failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Productivity Tool')),
      body: WebViewWidget(controller: _controller),
    );
  }
}

class TodoListPage extends StatefulWidget {
  const TodoListPage({super.key});

  @override
  _TodoListPageState createState() => _TodoListPageState();
}

class _TodoListPageState extends State<TodoListPage> {
  final TextEditingController _taskController = TextEditingController();
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/tasks.json');
      if (await file.exists()) {
        final contents = await file.readAsString();
        setState(() {
          _tasks = List<Map<String, dynamic>>.from(jsonDecode(contents));
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading tasks: $e')),
      );
    }
  }

  Future<void> _saveTasks() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/tasks.json');
      await file.writeAsString(jsonEncode(_tasks));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving tasks: $e')),
      );
    }
  }

  void _addTask() {
    if (_taskController.text.isNotEmpty) {
      setState(() {
        _tasks.add({'task': _taskController.text, 'completed': false});
        _taskController.clear();
      });
      _saveTasks();
    }
  }

  void _toggleTask(int index) {
    setState(() {
      _tasks[index]['completed'] = !_tasks[index]['completed'];
    });
    _saveTasks();
  }

  @override
  void dispose() {
    _taskController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Todo List Manager ✅'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _taskController,
              decoration: const InputDecoration(
                labelText: 'Enter Task',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _addTask,
              child: const Text('Add Task'),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _tasks.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Checkbox(
                      value: _tasks[index]['completed'],
                      onChanged: (value) => _toggleTask(index),
                    ),
                    title: Text(
                      _tasks[index]['task'],
                      style: TextStyle(
                        decoration: _tasks[index]['completed']
                            ? TextDecoration.lineThrough
                            : null,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuickNotePage extends StatefulWidget {
  const QuickNotePage({super.key});

  @override
  _QuickNotePageState createState() => _QuickNotePageState();
}

class _QuickNotePageState extends State<QuickNotePage> {
  final TextEditingController _noteController = TextEditingController();
  List<String> _notes = [];

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  Future<void> _loadNotes() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/notes.json');
      if (await file.exists()) {
        final contents = await file.readAsString();
        setState(() {
          _notes = List<String>.from(jsonDecode(contents));
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading notes: $e')),
      );
    }
  }

  Future<void> _saveNotes() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/notes.json');
      await file.writeAsString(jsonEncode(_notes));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving notes: $e')),
      );
    }
  }

  void _addNote() {
    if (_noteController.text.isNotEmpty) {
      setState(() {
        _notes.add(_noteController.text);
        _noteController.clear();
      });
      _saveNotes();
    }
  }

  void _deleteNote(int index) {
    setState(() {
      _notes.removeAt(index);
    });
    _saveNotes();
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quick Note Taker 📝'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _noteController,
              decoration: const InputDecoration(
                labelText: 'Enter Note',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _addNote,
              child: const Text('Save Note'),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _notes.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_notes[index]),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () => _deleteNote(index),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ParticipantsPage extends StatelessWidget {
  const ParticipantsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> participants = [
      {'name': 'Aliyu Ismail Lekan.'},
      {'name': 'Awwal Mubarak.'},
      {'name': 'Mcpraise Leightong Okoi', 'badge': '👨‍💻 Lead Developer'},
      {'name': 'Johnson Damilola.'},
      {'name': 'Ojo Michael Banji.'},
      {'name': 'Agbi Gabriel.'},
      {'name': 'Nwachukwu Francis.'},
      {'name': 'Sammy Wisdom.'},
      {'name': 'Adams Glory.'},
      {'name': 'Gerlong Sayilnen.'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Project Participants'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ...participants.map((participant) {
            return ListTile(
              title: Text(participant['name']!),
              subtitle: participant.containsKey('badge')
                  ? Text(
                      participant['badge']!,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.blue),
                    )
                  : null,
            );
          }).toList(),
          const SizedBox(height: 30),
          const Divider(),
          const SizedBox(height: 10),
          const Text(
            "🚀 Why this app matters",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            "This productivity toolkit is your everyday assistant, offering tools like QR generation, sketching, todo list management, quick note-taking, and a fun gaming feature to blow off some steam. "
            "Designed for accessibility and speed, it embodies efficiency, ease, and innovation — built for the world of 2025 and beyond. "
            "© April 6th, 2025.",
            style: TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}

class DocumentationPage extends StatelessWidget {
  const DocumentationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("📄 Documentation"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              "📱 About the App",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              "This application was meticulously crafted using Flutter for the frontend and Streamlit for the backend, "
              "offering tools designed to elevate productivity. Features include a QR code generator, digital sketchpad, "
              "todo list manager, quick note taker, and a special gaming feature to blow off some steam. All of these tools are integrated into one easy-to-use interface for maximum productivity.",
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            Text(
              "🛠 Tools Used:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              "- Flutter for frontend development\n- Streamlit for web-based tools\n- WebView for embedding tools\n- FilePicker for file uploads\n- Path Provider for local storage\n- Google Fonts for retro styling\n- Flutter Animate for button animations",
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 30),
            Text(
              "🌐 Future Enhancements",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              "Plans for future versions include:\n- Enhanced UI/UX\n- Integration with cloud-based file storage\n- Offline support\n- More interactive gaming features\n"
              "Stay tuned for more updates.",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
